# -*- coding: utf-8 -*-
'''templates这个模块主要存放ＨＴＭＬ文件'''

from flask import Flask

app=Flask(__name__)